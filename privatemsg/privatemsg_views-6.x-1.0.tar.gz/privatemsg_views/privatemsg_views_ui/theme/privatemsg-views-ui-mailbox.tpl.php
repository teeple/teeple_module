<?php

/**
 * @file
 * Privatemsg mailbox (a list of threads) template.
 * 
 * Available variables:
 * - $mailbox_view: themed mailbox view.
 */
?>

<?php print $mailbox_view; ?>